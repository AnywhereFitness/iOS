//
//  UserController.swift
//  AnywhereFitness
//
//  Created by brian vilchez on 1/9/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import Foundation
import CoreData

enum UserType: String {
  case instructor
  case client
}

class UserController {
    
    //MARK: - properties
    var `class`: Class?
    var user: User?
   // var token: Token?
    
    func createUser(withFirstName firstName: String, lastName: String, email: String, password: String, role: UserType ,context: NSManagedObjectContext) {
        let user = User(firstName: firstName, lastName: lastName, email: email, role: role.rawValue, id: "", context: context)
        self.user = user
        AnywhereFitnessAPI.shared.register(user: user, withPassword: password)
        CoreDataStack.saveContext()
        
    }
    
    func createClass(name: String, duration: String, startTime: String, endTIme: String,
                     instructor: String, intesityLevel: String, requirements: String, type:String,
                     location:String, size: String, price: String, context: NSManagedObjectContext = CoreDataStack.context) {
        let createdClass = Class(name: name, duration: duration, startTime: startTime, endTime: endTIme, id: "", instructor: instructor, intensityLevel: intesityLevel, requirements: requirements, type: type, location: location, size: size,price: price ,context: context)
        self.class = createdClass
        CoreDataStack.saveContext()
    }
    

    
    func updateClass(updateClass event: Class) {
        let _ = event
        deleteClass(forClass: event)
        CoreDataStack.saveContext()
    }
    
    func deleteClass(forClass instructorClass: Class) {
        CoreDataStack.context.delete(instructorClass)
        CoreDataStack.saveContext()
    }

    func updateIsReserved(forClass eventClass: Class) {
        eventClass.isReserved = !eventClass.isReserved
        CoreDataStack.saveContext()
    }
}

extension UserController {
    
    func updateName(with name: String) {
        self.class?.name = name
        CoreDataStack.saveContext()
    }
    
    func updateduration(with duration: String) {
           self.class?.duration = duration
           CoreDataStack.saveContext()
       }
    
    func updateStartTime(withStartTime startTime: String) {
        self.class?.startTime = startTime
        CoreDataStack.saveContext()
    }
    
    func updateEndTime(with endTIme: String) {
           self.class?.endTime = endTIme
           CoreDataStack.saveContext()
       }
    
    func updateInstructor(with name: String) {
           self.class?.instructor = name
           CoreDataStack.saveContext()
       }
    func updateIntesityLevel(with Intesity: String) {
           self.class?.intensityLevel = Intesity
           CoreDataStack.saveContext()
       }
    func updateRequirements(with requirements: String) {
           self.class?.requirements = requirements
           CoreDataStack.saveContext()
       }
    func updateType(with type: String) {
           self.class?.type = type
           CoreDataStack.saveContext()
       }
    func updateLocation(with location: String) {
           self.class?.location = location
           CoreDataStack.saveContext()
       }
    func updateSize(with size: String) {
           self.class?.size = size
           CoreDataStack.saveContext()
       }
    func updatePrice(with price: String) {
           self.class?.price = price
           CoreDataStack.saveContext()
       }
}
