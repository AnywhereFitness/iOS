//
//  InstructorSignUpViewController.swift
//  AnywhereFitness
//
//  Created by Brandi Bailey on 1/7/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import UIKit
import CoreData

class InstructorSignUpViewController: UIViewController {

    //MARK: - Properties
    @IBOutlet weak var signUpBackButton: UIButton!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    var user = User()
    var userController = UserController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: - actions
    @IBAction func instructorConfirmButton(_ sender: Any) {
        guard let firstName = firstNameTextField.text,
            !firstName.isEmpty, let lastName = lastNameTextField.text,
            !lastName.isEmpty, let email = emailTextField.text,
            !email.isEmpty, let password = passwordTextField.text,
            !password.isEmpty else { return }
        
        userController.createUser(withFirstName: firstName, lastName: lastName, email: email, password: password, role: .instructor, context: CoreDataStack.context)
    }
    
}
