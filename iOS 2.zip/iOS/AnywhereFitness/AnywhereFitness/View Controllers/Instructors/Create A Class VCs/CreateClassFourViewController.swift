//
//  CreateClassFourViewController.swift
//  AnywhereFitness
//
//  Created by Brandi Bailey on 1/8/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import UIKit
import CoreData

class CreateClassFourViewController: UIViewController {
    
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var whenToArriveTextField: UITextField!
    @IBOutlet weak var whatYouShouldKnowTextField: UITextView!
    @IBOutlet weak var finishCreateClassButton: UIButton!
    var userController: UserController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func finishButtonTapped(_ sender: Any) {
        guard let address = addressTextField.text, !address.isEmpty, let arrival = whenToArriveTextField.text, !arrival.isEmpty, let notes = whatYouShouldKnowTextField.text, !notes.isEmpty else { return }
        userController?.updateLocation(with: address)
    }
    
}
