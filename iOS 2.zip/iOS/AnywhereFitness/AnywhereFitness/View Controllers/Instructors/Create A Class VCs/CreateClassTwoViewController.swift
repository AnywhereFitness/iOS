//
//  CreateClassTwoViewController.swift
//  AnywhereFitness
//
//  Created by Brandi Bailey on 1/7/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import UIKit
import CoreData

class CreateClassTwoViewController: UIViewController {

    @IBOutlet weak var classDescription: UITextView!
    @IBOutlet weak var classNameTextfield: UITextField!
    var userController: UserController?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func nextButtonPressed(_ sender: UIButton) {
        guard let name = classNameTextfield.text, !name.isEmpty,
            let description = classDescription.text, !description.isEmpty else { return }
        userController?.updateName(with: name)
    }
    
    
    // MARK: - Navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "ClassSegue" {
    guard let nextVC = segue.destination as? CreateClassThreeViewController else { return }
    nextVC.userController = userController
        }
    }

}
