//
//  ClassDetailViewController.swift
//  AnywhereFitness
//
//  Created by Brandi Bailey on 1/8/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import UIKit
import CoreData

class ClassDetailViewController: UIViewController {

    @IBOutlet weak var className: UILabel!
    @IBOutlet weak var classType: UILabel!
    @IBOutlet weak var skillLevel: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var classDaysLabel: UILabel!
    @IBOutlet weak var classStartTime: UILabel!
    @IBOutlet weak var classDuration: UILabel!
    @IBOutlet weak var whenToArrive: UITextView!
    @IBOutlet weak var detailsTextView: UITextView!
    @IBOutlet weak var reuiqrementsLabel: UITextView!
    @IBOutlet weak var registeredClietns: UITextView!
    var classEvent: Class? {
        didSet {
            updateViews()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }

    private func updateViews() {
        guard isViewLoaded else { return }
        guard let classEvent = classEvent else { return }
        className.text = classEvent.name
        classType.text = classEvent.type
        skillLevel.text = classEvent.intensityLevel
        price.text = classEvent.price
        addressLabel.text = classEvent.location
        classStartTime.text = classEvent.startTime
        classDuration.text = classEvent.duration
        whenToArrive.text = "please arrive 15 minutes early"
        detailsTextView.text = "if you have an questiosn please reach out to me"
        reuiqrementsLabel.text = classEvent.requirements
        registeredClietns.text = ""
        
    }
    
    
}
