//
//  IntroScreenViewController.swift
//  AnywhereFitness
//
//  Created by Brandi Bailey on 1/7/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import UIKit
import CoreData

class IntroScreenViewController: UIViewController {
    
    //MARK: - Properties
    @IBOutlet weak var signInButton: UIButton!
    var userController = UserController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureViews()
    }
    
    //MARK: - Actions
    @IBAction func signInTapped(_ sender: Any) {
        let alert = UIAlertController(title: "Sign In", message: nil, preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "email"
            alert.addTextField { (textField) in
                textField.placeholder = "Password"
            }
        }
        let action = UIAlertAction(title: "Submit", style: .default) { (_) in
            
            guard let username = alert.textFields?.first?.text else { return }
            guard let password = alert.textFields?.last?.text else { return }
            
            AnywhereFitnessAPI.shared.login(withEmail: username, password: password) { (error) in
                if let error = error {
                    NSLog("Error Logging In: \(error)")
                    return
                } else {
                    DispatchQueue.main.sync {
                        if AnywhereFitnessAPI.shared.user?.role == "client" {
                            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "ClienthomeScreenTab") else { return }
                            vc.modalPresentationStyle = .fullScreen
                            self.present(vc, animated: true, completion: nil)
                        } else {
                            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "homeScreenTab") else { return }
                            vc.modalPresentationStyle = .fullScreen
                            self.present(vc, animated: true, completion: nil)
                        } 
                    }
                }
            }
        }
            
            alert.addAction(action)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
            present(alert, animated: true, completion: nil)
            
        }
        
    
    //MARK: - Helper Methods
    private func configureViews() {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        if AnywhereFitnessAPI.shared.token != nil && AnywhereFitnessAPI.shared.user?.role == "instructor" {
                  performSegue(withIdentifier: "ToInstructorStartSegue", sender: self)
              } else {
            if AnywhereFitnessAPI.shared.token != nil && AnywhereFitnessAPI.shared.user?.role == "client" {
                      performSegue(withIdentifier: "ToClientStartSegue", sender: self)
                  }
              }
    }
    
   @IBAction func unwindTologinScreen(segue: UIStoryboardSegue) {
        AnywhereFitnessAPI.shared.user = nil
        AnywhereFitnessAPI.shared.token = nil
    }

}
