//
//  User+Convenience.swift
//  AnywhereFitness
//
//  Created by brian vilchez on 1/9/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import Foundation
import CoreData

extension User {
    
    var userRepresentation: UserRepresentation? {
        guard let firstName = firstName,
        let lastName = lastName,
        let role = role,
        let email = email,
            let id = id else  { return nil}
        
         return UserRepresentation(email: email, firstName: firstName, lastName: lastName, role: role, id: id)
    }
    
    convenience init(firstName: String,
                     lastName: String,
                     email: String,
                     role: String,
                     id: String,
                     context: NSManagedObjectContext = CoreDataStack.context) {
        self.init(context:context)
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.role = role
        self.id = id
    }
}
