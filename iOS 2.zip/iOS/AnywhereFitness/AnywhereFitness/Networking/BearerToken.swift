//
//  BearerToken.swift
//  AnywhereFitness
//
//  Created by brian vilchez on 1/8/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import Foundation

struct BearerToken: Codable {
    let token: String
}
