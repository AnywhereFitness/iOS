//
//  AnywhereFitnessTests.swift
//  AnywhereFitnessTests
//
//  Created by Brandi Bailey on 1/7/20.
//  Copyright © 2020 Brandi Bailey. All rights reserved.
//

import XCTest
@testable import AnywhereFitness

class AnywhereFitnessTests: XCTestCase {

    let anyTImeAPI = AnywhereFitnessAPI()
    let client = User(firstName: "oodles12", lastName: "pizza", email: "my@gmail.com", role: "client", id: "")
    let instructor = User(firstName: "ben", lastName: "adam", email: "ben@gmail.com", role: "instructor", id: "")
    let userController = UserController()
    
      func testLogin() {
        anyTImeAPI.login(withEmail:"my@gmail.com", password: "123456")
      }
      
      func testRegister() {
        anyTImeAPI.register( user: client, withPassword: "123456") { (error) in
            if let error = error {
                NSLog("error logging in : \(error)")
                return
            }
        }
        print(self.anyTImeAPI.user)
      }
      
    func testUSer() {
        guard let userRep = anyTImeAPI.user else { return }
        if userRep.firstName == "bob" && userRep.lastName == "fett" {
            XCTAssert(true, "🔥")
            } else {
        XCTAssert(false, "🖕🏻")
            }
    }
    
      func testCreatingClass() {
        userController.createClass(name: "yoga 101", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
        print(userController.class)
        if userController.class?.name == "yoga 101" {
            XCTAssert(true)
        } else {
            XCTAssert(false)
        }
    }
      
      
    func testUpdateName() {
        
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
        userController.class?.name = "pizza"
        if userController.class?.name == "pizza" {
            XCTAssert(true)
        } else {
            XCTAssert(false)
        }
        }

      
      func testUpdateduration() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
        userController.class?.duration = "pizza"
                  if userController.class?.duration == "pizza" {
                      XCTAssert(true )
                  } else {
                      XCTAssert(false)
                  }
           
         }
      
      func testUpdateStartTime() {
       userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
         userController.class?.startTime = "pizza"
               if userController.class?.startTime == "pizza" {
                   XCTAssert(true)
               } else {
                   XCTAssert(false)
               }
      }
      
      func testUpdateEndTime() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
             userController.class?.endTime = "pizza"
                   if userController.class?.endTime == "pizza" {
                       XCTAssert(true)
                   } else {
                       XCTAssert(false)
                   }
             
         }
      
      func testUpdateInstructor() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
           userController.class?.instructor = "pizza"
                 if userController.class?.instructor == "pizza" {
                     XCTAssert(true)
                 } else {
                     XCTAssert(false)
                 }
          
         }
      func testUpdateIntesityLevel() {
         userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
           userController.class?.intensityLevel = "pizza"
                 if userController.class?.intensityLevel == "pizza" {
                     XCTAssert(true)
                 } else {
                     XCTAssert(false)
                 }
         }
      func testUpdateRequirements() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
           userController.class?.requirements = "pizza"
                 if userController.class?.requirements == "pizza" {
                     XCTAssert(true)
                 } else {
                     XCTAssert(false)
                 }
          
         }
      func testUpdateType() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
            userController.class?.type = "pizza"
                  if userController.class?.type == "pizza" {
                      XCTAssert(true)
                  } else {
                      XCTAssert(false)
                  }
          
         }
    
      func testUpdateLocation() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
          userController.class?.location = "pizza"
                if userController.class?.location == "pizza" {
                    XCTAssert(true)
                } else {
                    XCTAssert(false)
                }
         }
    
      func testUpdateSize() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
           userController.class?.size = "pizza"
                 if userController.class?.size == "pizza" {
                     XCTAssert(true)
                 } else {
                     XCTAssert(false)
                 }
            
         }
    
      func testUpdatePrice() {
        userController.createClass(name: "pizza", duration: "1 hour", startTime: "1 pm", endTIme: "2 pm", instructor: "me", intesityLevel: "beginner", requirements: "none", type: "yoga", location: "SLC", size: "2 people", price: "15 dollars")
           userController.class?.price = "pizza"
                 if userController.class?.price == "pizza" {
                     XCTAssert(true)
                 } else {
                     XCTAssert(false)
                 }
            
         }

}
